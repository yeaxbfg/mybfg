import asyncio
import requests
import os

from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram import types, Dispatcher

from assets.antispam import new_earning, antispam_earning, admin_only
from assets import keyboards as kb
from filters.custom import TextIn, StartsWith
from user import BFGuser
import config as cfg
from bot import dp

MODULES = {}
CATALOG = {}
MOD_TYPE = "games"


def load_modules(dp: Dispatcher) -> None:
    """Загрузка модулей при включении бота"""
    txt, mlist = 0, []
    
    for filename in os.listdir("modules"):
        if filename.endswith(".py") and filename != "__init__.py" and not filename.startswith("add"):
            fmodule_name = filename[:-3]
            module = __import__(f"modules.{fmodule_name}", fromlist=["register_handlers"])
            module.register_handlers(dp)
            txt += 1
            
            if hasattr(module, "MODULE_DESCRIPTION"):
                module_info = module.MODULE_DESCRIPTION
                module_name = module_info.get("name", "Без названия")
                module_description = module_info.get("description", "Нет описания")
                mlist.append(module_name)
                MODULES[fmodule_name] = {"name": module_name, "description": module_description}
    
    if txt > 0:
        mlist = ", ".join(mlist)
        print(f"Загрузка модулей \"{mlist}\"")
        print(f"Импортировано {txt} модулей.")


def load_new_mod(filename: str, dp: Dispatcher) -> None:
    """Регестрация хандлеров нового модуля (при загрузке командой)"""
    if filename.endswith(".py") and filename != "__init__.py" and not filename.startswith("add"):
        fmodule_name = filename[:-3]
        module = __import__(f"modules.{fmodule_name}", fromlist=["register_handlers"])
        module.register_handlers(dp)
        
        if hasattr(module, "MODULE_DESCRIPTION"):
            module_info = module.MODULE_DESCRIPTION
            module_name = module_info.get("name", "Без названия")
            module_description = module_info.get("description", "Нет описания")
            MODULES[fmodule_name] = {"name": module_name, "description": module_description}


@admin_only(private=True)
async def modules_menu(message: types.Message):
    await message.answer("<b>🛡 Меню модулей:</b>", reply_markup=kb.modules_menu())
    

@admin_only(private=True)
async def load_modules_cmd(message: types.Message):
    user_id = message.from_user.id
    if not MODULES:
        await message.answer("У вас нет загруженых модулей.")
        return

    module_keys = list(MODULES.keys())
    mod = module_keys[0]
    
    txt = f"✨ Модуль <code>{MODULES[mod]['name']}</code>\n<i>{MODULES[mod]['description']}</i>"
    
    msg = await message.answer(txt, reply_markup=kb.my_modules_kb(module_keys, 0, user_id, mod))
    await new_earning(msg)
    

@antispam_earning
async def load_modules_next(call: types.CallbackQuery, user: BFGuser):
    user_id = user.user_id

    if not MODULES or len(MODULES) < 2:
        return

    current_index = int(call.data.split("_")[1])
    type = call.data.split("_")[2].split("|")[0]
    module_keys = list(MODULES.keys())

    if type == "down":
        current_index = (current_index - 1) % len(module_keys)
    else:
        current_index = (current_index + 1) % len(module_keys)

    mod = module_keys[current_index]

    keyboard = InlineKeyboardMarkup(row_width=3)
    keyboard.row(
        InlineKeyboardButton(text="‹", callback_data=f"mymodules-list_{current_index}_down|{user_id}"),
        InlineKeyboardButton(text=f"{current_index+1}/{len(module_keys)}", callback_data="userbotik"),
        InlineKeyboardButton(text="›", callback_data=f"mymodules-list_{current_index}_up|{user_id}")
    )
    keyboard.add(InlineKeyboardButton(text="❌ Удалить", callback_data=f"dell-modul_{mod}|{user_id}"))

    txt = f"✨ Модуль <code>{MODULES[mod]['name']}</code>\n<i>{MODULES[mod]['description']}</i>"
    
    await call.message.edit_text(txt, reply_markup=kb.my_modules_kb(module_keys, current_index, user_id, mod))


@antispam_earning
async def dell_mod(call: types.CallbackQuery, user: BFGuser):
    name = call.data.split("_")[1].split("|")[0]
    path = f"modules/{name}.py"
    
    await call.message.edit_text("<i>🚮 Удаление модуля...</i>")
    await asyncio.sleep(0.3)

    if os.path.exists(path):
        os.remove(path)
        await call.message.edit_text(f"🗑 Модуль <b>{name}</b> успешно удален!\n<i>Перезагрузите бота чтобы изменения вступили в силу</i>")
    else:
        await call.message.edit_text(f"❌ Модуль <b>{name}</b> не найден.")


@admin_only(private=True)
async def catalog_modules(message: types.Message):
    user_id = message.from_user.id
    global CATALOG
    
    try:
        response = requests.get("https://raw.githubusercontent.com/Ijidishurka/bfg-modules/refs/heads/V3/modules.json")
        CATALOG = response.json()
    except:
        pass
    
    if not CATALOG:
        await message.answer("Модули не найдены.")
        return
    
    txt = "🌟 Выберите тип модулей:"
    colvo = (len(CATALOG["games"]), len(CATALOG["events"]), len(CATALOG["other"]), len(CATALOG["system"]))
    
    msg = await message.answer(txt, reply_markup=kb.load_modules_type(user_id, colvo))
    await new_earning(msg)


@antispam_earning
async def catalog_type(call: types.CallbackQuery, user: BFGuser):
    global MOD_TYPE
    MOD_TYPE = call.data.split("_")[1].split("|")[0]
    
    if len(CATALOG[MOD_TYPE]) == 0:
        return
    
    module_keys = list(CATALOG[MOD_TYPE].keys())
    mod = CATALOG[MOD_TYPE][module_keys[0]]
    name = list(CATALOG[MOD_TYPE].keys())[0]

    txt = f"✨ Модуль <code>{mod['name']}</code>\n<i>{mod['description']}</i>"

    await call.message.edit_text(txt, reply_markup=kb.load_modules_kb(module_keys, 0, user.id, name, MODULES))
    

@antispam_earning
async def catalog_modules_next(call: types.CallbackQuery, user: BFGuser):
    if not CATALOG[MOD_TYPE] or len(CATALOG[MOD_TYPE]) < 2:
        return
    
    current_index = int(call.data.split("_")[1])
    type = call.data.split("_")[2].split("|")[0]
    module_keys = list(CATALOG[MOD_TYPE].keys())
    
    if type == "down":
        current_index = (current_index - 1) % len(module_keys)
    else:
        current_index = (current_index + 1) % len(module_keys)

    mod = CATALOG[MOD_TYPE][module_keys[current_index]]
    name = list(CATALOG[MOD_TYPE].keys())[current_index]
    txt = f"✨ Модуль <code>{mod['name']}</code>\n<i>{mod['description']}</i>"
    
    await call.message.edit_text(txt, reply_markup=kb.load_modules_kb(module_keys, current_index, user.id, name, MODULES))
    
    
@antispam_earning
async def load_mod(call: types.CallbackQuery, user: BFGuser):
    name = call.data.split("_")[1].split("|")[0]
    url = CATALOG[MOD_TYPE].get(name, {}).get("url", None)
    
    if not url:
        return
    
    await call.message.edit_text("<i>⚡️ Загрузка модуля...</i>")
    await asyncio.sleep(0.3)
    
    response = requests.get(url)
    if response.status_code == 200:
        filename = url.split("/")[-1]
        
        with open(f"modules/{filename}", "wb") as file:
            file.write(response.content)
            
        load_new_mod(filename, dp)
        await call.message.edit_text(f"🌟 <b>Модуль {CATALOG[MOD_TYPE][name]['name']} загружен!</b>\n<i>{CATALOG[MOD_TYPE][name]['description']}</i>")
    else:
        await call.message.edit_text(f"🍎 Ошибка загрузки модуля.")
        
        
@admin_only(private=True)
async def load_mod_cmd(message: types.Message):
    if not cfg.custom_modules:
        await message.answer(text="❌ <i>Загрузка кастомных модулей отключена в конфиге (config.py)</i>")
        return

    try:
        url = "".join(message.text.split()[1:])

        msg = await message.answer(text="<i>⚡️ Загрузка модуля...</i>")
        await asyncio.sleep(0.3)
    
        response = requests.get(url)

        if response.status_code == 200:
            filename = url.split("/")[-1]

            with open(f"modules/{filename}", "wb") as file:
                file.write(response.content)

            load_new_mod(filename, dp)

            await msg.edit_text(text=f"🌟 Модуль {url} загружен")
        else:
            await msg.edit_text(text=f"🍎 Ошибка загрузки модуля ({response.status_code}).")
    except Exception as e:
        await message.answer(text=f"🍎 Ошибка загрузки модуля.\n<code>{str(e)}</code>")


def reg(dp: Dispatcher):
    dp.message.register(modules_menu, TextIn("🌟 Модули"))
    dp.message.register(load_modules_cmd, TextIn("🛎 Загруженые"))
    dp.callback_query.register(load_modules_next, StartsWith("mymodules-list_"))
    dp.callback_query.register(dell_mod, StartsWith("dell-modul_"))
    dp.message.register(catalog_modules, TextIn("📂 Каталог"))
    dp.callback_query.register(catalog_type, StartsWith("mod-catalog_"))
    dp.callback_query.register(catalog_modules_next, StartsWith("catalogmod-list_"))
    dp.callback_query.register(load_mod, StartsWith("load-modul_"))
    dp.message.register(load_mod_cmd, Command("loadmodb"))
