API_TOKEN = '8225978216:AAE8Fx2D0_8kbwYea9eKh3RFGEUMEnQA6o4'

admin = [6207977401]
start_money = 500000000

bot_name = 'bfg'
chat = '1'
channel = '1'
admin_username = 'btwcry'
bot_username = 'bfgcopybot'

chat_log = 0
cleaning = 60

custom_modules = True